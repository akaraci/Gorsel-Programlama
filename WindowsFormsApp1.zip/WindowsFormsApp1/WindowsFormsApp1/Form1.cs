﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnmesajver_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Hello World");
            //MessageBox.Show("Hello world", "İlk mesaj title");
           
            DialogResult cevap=MessageBox.Show("Çıkmak istedğinize emin misiniz?", "Uyarı",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            //MessageBox.Show(cevap.ToString());
            if (cevap == DialogResult.Yes)
            {
                MessageBox.Show("Evet butonuna tıklandı");
            }
            else
            {
                MessageBox.Show("Hayır Butonuna tıklandı");
            }
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show("Forma çift tıklandı");
        }
    }
}
